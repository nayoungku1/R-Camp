## ---- eval = FALSE-------------------------------------------------------
## install.packages("tidyverse")

## ---- eval = FALSE-------------------------------------------------------
## if(!require(devtools)) install.packages("devtools")
## devtools::install_github("kassambara/ggpubr")

## ---- eval = FALSE-------------------------------------------------------
install.packages("ggpubr")
install.packages("ggplot2")

## ------------------------------------------------------------------------
library("ggplot2")
library("ggpubr")

## ---- echo = FALSE, comment = NA-----------------------------------------
head(as.data.frame(mpg[, 1:7]), 4)

## ---- eval = FALSE-------------------------------------------------------
## library("readr")
## 
## # Reads tab delimited files (.txt tab)
## my_data <- read_tsv(file.choose())
## 
## # Reads comma (,) delimited files (.csv)
## my_data <- read_csv(file.choose())
## 
## # Reads semicolon(;) separated files(.csv)
## my_data <- read_csv2(file.choose())

## ------------------------------------------------------------------------
data("iris")   # Loading
head(iris, n = 3)  # Print the first n = 3 rows

## ---- eval = FALSE-------------------------------------------------------
## ?iris

## Note that, dplyr package allows to use the forward-pipe chaining operator (%>%) for combining multiple operations. For example, x %>% f is equivalent to f(x). Using the pipe (%>%), the output of each operation is passed to the next operation. This makes R programming easy.

## ----r-base-graphics-examples, echo = -1, fig.width=3.3------------------
par(mar = c(4, 4, 1, 1))
# (1) Create a scatter lot
plot(
  x = iris$Sepal.Length, y = iris$Sepal.Width,
  pch = 19, cex = 0.8, frame = FALSE,
  xlab = "Sepal Length",ylab = "Sepal Width"
  )

# (2) Create a box plot
boxplot(Sepal.Length ~ Species, data = iris,
        ylab = "Sepal.Length", 
        frame = FALSE, col = "lightgray")

## Read more examples at: R base Graphics on STHDA, http://www.sthda.com/english/wiki/r-base-graphs

## The lattice package uses formula interface. For example, in lattice terminology, the formula y ~ x | group, means that we want to plot the y variable according to the x variable, splitting the plot into multiple panels by the variable group.

## ----lattice-scatter-plot, fig.width=3, fig.height=3, fig.show="asis"----
library("lattice")
xyplot(
  Sepal.Length ~ Petal.Length, group = Species, 
  data = iris, auto.key = TRUE, pch = 19, cex = 0.5
  )

## ----lattice-scatter-plot-multiple-panels, fig.width=6, fig.height=2.7----
xyplot(
  Sepal.Length ~ Petal.Length | Species, 
  layout = c(3, 1),               # panel with ncol = 3 and nrow = 1
  group = Species, data = iris,
  type = c("p", "smooth"),        # Show points and smoothed line
  scales = "free"                 # Make panels axis scales independent
  )

## Read more examples at: [Lattice Graphics on STHDA](http://www.sthda.com/english/wiki/lattice-graphs)

## The ggplot2 syntax might seem opaque for beginners, but once you understand the basics, you can create and customize any kind of plots you want.

## ----ggplot-scatter-plot, fig.width=3, fig.height=2.7--------------------
library(ggplot2)
ggplot(iris, aes(x = Sepal.Length, y = Sepal.Width))+
  geom_point()

# Change point size, color and shape
ggplot(iris, aes(x = Sepal.Length, y = Sepal.Width))+
  geom_point(size = 1.2, color = "steelblue", shape = 21)

## ----plotting-symbol, fig.width=2.3, fig.height=2.3, eval = FALSE--------
## ggpubr::show_point_shapes()

## ----ggplot-aesthetic-mapping-control-points-color-shape-and-size, fig.width=3.3, fig.height=2.7----
# Control points color by groups
ggplot(iris, aes(x = Sepal.Length, y = Sepal.Width))+
  geom_point(aes(color = Species, shape = Species))

# Change the default color manually.
# Use the scale_color_manual() function
ggplot(iris, aes(x = Sepal.Length, y = Sepal.Width))+
  geom_point(aes(color = Species, shape = Species))+
  scale_color_manual(values = c("#00AFBB", "#E7B800", "#FC4E07"))

## ----ggplot-scatter-plot-with-regression-line, fig.width=6.5, fig.height=2.7----
ggplot(iris, aes(x = Sepal.Length, y = Sepal.Width))+
  geom_point(aes(color = Species))+               
  geom_smooth(aes(color = Species, fill = Species))+
  facet_wrap(~Species, ncol = 3, nrow = 1)+
  scale_color_manual(values = c("#00AFBB", "#E7B800", "#FC4E07"))+
  scale_fill_manual(values = c("#00AFBB", "#E7B800", "#FC4E07"))

## ------------------------------------------------------------------------
theme_set(
  theme_classic()
)

## ----ggplot-examples-of-plots, fig.width=3, fig.height=2.5---------------
ggplot(iris, aes(x = Sepal.Length, y = Sepal.Width))+
  geom_point()

## ----ggpubr-density-plot, fig.width=3, fig.height=3, warning=FALSE, fig.show="asis"----
library(ggpubr)
# Density plot with mean lines and marginal rug
ggdensity(iris, x = "Sepal.Length",
   add = "mean", rug = TRUE,             # Add mean line and marginal rugs
   color = "Species", fill = "Species",  # Color by groups
   palette = "jco")                      # use jco journal color palette

## Note that the argument `palette` can take also a custom color palette. For example `palette= c("#00AFBB", "#E7B800", "#FC4E07")`.

## ----ggpubr-box-plot-with-strip-charts-and-p-values, fig.width=4, fig.height=4, fig.show="asis"----
# Groups that we want to compare
my_comparisons <- list(
  c("setosa", "versicolor"), c("versicolor", "virginica"),
  c("setosa", "virginica")
)

# Create the box plot. Change colors by groups: Species
# Add jitter points and change the shape by groups
ggboxplot(
  iris, x = "Species", y = "Sepal.Length",
  color = "Species", palette = c("#00AFBB", "#E7B800", "#FC4E07"),
  add = "jitter"
  )+
  stat_compare_means(comparisons = my_comparisons, method = "t.test")

## Learn more on STHDA at: [ggpubr: Publication Ready Plots](http://www.sthda.com/english/articles/24-ggpubr-publication-ready-plots/)

## ---- eval = FALSE-------------------------------------------------------
## pdf("r-base-plot.pdf")
## # Plot 1 --> in the first page of PDF
## plot(x = iris$Sepal.Length, y = iris$Sepal.Width)
## # Plot 2 ---> in the second page of the PDF
## hist(iris$Sepal.Length)
## dev.off()

## ---- eval = FALSE-------------------------------------------------------
## # Create some plots
## library(ggplot2)
## myplot1 <- ggplot(iris, aes(Sepal.Length, Sepal.Width)) +
##   geom_point()
## myplot2 <- ggplot(iris, aes(Species, Sepal.Length)) +
##   geom_boxplot()
## 
## # Print plots to a pdf file
## pdf("ggplot.pdf")
## print(myplot1)     # Plot 1 --> in the first page of PDF
## print(myplot2)     # Plot 2 ---> in the second page of the PDF
## dev.off()

## See also the following blog post to [save high-resolution ggplots](http://www.sthda.com/english/wiki/saving-high-resolution-ggplots-how-to-preserve-semi-transparency)

