## ------------------------------------------------------------------------
library(ggplot2)
library(ggpubr)
theme_set(theme_pubr())

## ----frequency-graph-using-geom_bar-discrete-variable, fig.width=4.7, fig.height=2.7----
ggplot(diamonds, aes(cut)) +
  geom_bar(fill = "#0073C2FF") +
  theme_pubclean()

## ----annotated-frequency-bar-plot, fig.width=4.7, fig.height=3.2---------
# Compute the frequency
library(dplyr)
df <- diamonds %>%
  group_by(cut) %>%
  summarise(counts = n())
df

# Create the bar plot. Use theme_pubclean() [in ggpubr]
ggplot(df, aes(x = cut, y = counts)) +
  geom_bar(fill = "#0073C2FF", stat = "identity") +
  geom_text(aes(label = counts), vjust = -0.3) + 
  theme_pubclean()

## ------------------------------------------------------------------------
df <- df %>%
  arrange(desc(cut)) %>%
  mutate(prop = round(counts*100/sum(counts), 1),
         lab.ypos = cumsum(prop) - 0.5*prop)
head(df, 4)

## ----ggplot-pie-charts, fig.width=4, fig.height=4------------------------
ggplot(df, aes(x = "", y = prop, fill = cut)) +
  geom_bar(width = 1, stat = "identity", color = "white") +
  geom_text(aes(y = lab.ypos, label = prop), color = "white")+
  coord_polar("y", start = 0)+
  ggpubr::fill_palette("jco")+
  theme_void()

## ---- eval = FALSE-------------------------------------------------------
## ggpie(
##   df, x = "prop", label = "prop",
##   lab.pos = "in", lab.font = list(color = "white"),
##   fill = "cut", color = "white",
##   palette = "jco"
## )

## ----frequency-dot-charts, fig.width=5, fig.height=3---------------------
ggplot(df, aes(cut, prop)) +
  geom_linerange(
    aes(x = cut, ymin = 0, ymax = prop), 
    color = "lightgray", size = 1.5
    )+
  geom_point(aes(color = cut), size = 2)+
  ggpubr::color_palette("jco")+
  theme_pubclean()

## ---- eval = FALSE-------------------------------------------------------
## ggdotchart(
##   df, x = "cut", y = "prop",
##   color = "cut", size = 3,      # Points color and size
##   add = "segment",              # Add line segments
##   add.params = list(size = 2),
##   palette = "jco",
##   ggtheme = theme_pubclean()
## )

## ------------------------------------------------------------------------
set.seed(1234)
wdata = data.frame(
        sex = factor(rep(c("F", "M"), each=200)),
        weight = c(rnorm(200, 55), rnorm(200, 58))
        )

head(wdata, 4)

## ------------------------------------------------------------------------
library("dplyr")
mu <- wdata %>% 
  group_by(sex) %>%
  summarise(grp.mean = mean(weight))
mu

## ------------------------------------------------------------------------
a <- ggplot(wdata, aes(x = weight))

## ----basic-density-plot, fig.width=3, fig.height=2-----------------------
# y axis scale = ..density.. (default behaviour)
a + geom_density() +
  geom_vline(aes(xintercept = mean(weight)), 
             linetype = "dashed", size = 0.6)
  
# Change y axis to count instead of density
a + geom_density(aes(y = ..count..), fill = "lightgray") +
  geom_vline(aes(xintercept = mean(weight)), 
             linetype = "dashed", size = 0.6,
             color = "#FC4E07")

## ----density-change-color-by-groups--------------------------------------
# Change line color by sex
a + geom_density(aes(color = sex)) +
  scale_color_manual(values = c("#868686FF", "#EFC000FF"))

# Change fill color by sex and add mean line
# Use semi-transparent fill: alpha = 0.4
a + geom_density(aes(fill = sex), alpha = 0.4) +
      geom_vline(aes(xintercept = grp.mean, color = sex),
             data = mu, linetype = "dashed") +
  scale_color_manual(values = c("#868686FF", "#EFC000FF"))+
  scale_fill_manual(values = c("#868686FF", "#EFC000FF"))

## ----ggpubr-density-plots------------------------------------------------
library(ggpubr)

# Basic density plot with mean line and marginal rug
ggdensity(wdata, x = "weight", 
          fill = "#0073C2FF", color = "#0073C2FF",
          add = "mean", rug = TRUE)
     
# Change outline and fill colors by groups ("sex")
# Use a custom palette
ggdensity(wdata, x = "weight",
   add = "mean", rug = TRUE,
   color = "sex", fill = "sex",
   palette = c("#0073C2FF", "#FC4E07"))

## ----basic-histograms----------------------------------------------------
a + geom_histogram(bins = 30, color = "black", fill = "gray") +
  geom_vline(aes(xintercept = mean(weight)), 
             linetype = "dashed", size = 0.6)

## Note that, by default:

## ----histogram-change-color-by-groups, fig.width=3.4---------------------
# Change line color by sex
a + geom_histogram(aes(color = sex), fill = "white", 
                   position = "identity") +
  scale_color_manual(values = c("#00AFBB", "#E7B800")) 

# change fill and outline color manually 
a + geom_histogram(aes(color = sex, fill = sex),
                         alpha = 0.4, position = "identity") +
  scale_fill_manual(values = c("#00AFBB", "#E7B800")) +
  scale_color_manual(values = c("#00AFBB", "#E7B800"))

## ----combine-density-and-histogram, fig.width=3.3, fig.height=3----------
# Histogram with density plot
a + geom_histogram(aes(y = ..density..), 
                   colour="black", fill="white") +
  geom_density(alpha = 0.2, fill = "#FF6666") 
     

# Color by groups
a + geom_histogram(aes(y = ..density.., color = sex), 
                   fill = "white",
                   position = "identity")+
  geom_density(aes(color = sex), size = 1) +
  scale_color_manual(values = c("#868686FF", "#EFC000FF"))

## ----ggpubr-histogram, fig.width=3.4-------------------------------------
library(ggpubr)

# Basic histogram plot with mean line and marginal rug
gghistogram(wdata, x = "weight", bins = 30, 
            fill = "#0073C2FF", color = "#0073C2FF",
            add = "mean", rug = TRUE)
     
# Change outline and fill colors by groups ("sex")
# Use a custom palette
gghistogram(wdata, x = "weight", bins = 30,
   add = "mean", rug = TRUE,
   color = "sex", fill = "sex",
   palette = c("#0073C2FF", "#FC4E07"))

## ------------------------------------------------------------------------
theme_set(theme_pubclean())

## ----frequency-polygon-and-area-plot-------------------------------------
# Basic frequency polygon
a + geom_freqpoly(bins = 30) 

# Basic area plots, which can be filled by color
a + geom_area( stat = "bin", bins = 30,
               color = "black", fill = "#00AFBB")

## ----frequency-polygon-and-area-plot-color-by-groups, fig.height=3.3-----
# Frequency polygon: 
# Change line colors and types by groups
a + geom_freqpoly( aes(color = sex, linetype = sex),
                   bins = 30, size = 1.5) +
  scale_color_manual(values = c("#00AFBB", "#E7B800"))

# Area plots: change fill colors by sex
# Create a stacked area plots
a + geom_area(aes(fill = sex), color = "white", 
              stat ="bin", bins = 30) +
  scale_fill_manual(values = c("#00AFBB", "#E7B800"))

## As in histogram plots, the default y values is count. To have density values on y axis, specify `y = ..density..` in `aes()`.

## ----geom_dotplot-one-variable, fig.width = 4, fig.height=3.5------------
a + geom_dotplot(aes(fill = sex), binwidth = 1/4) +
  scale_fill_manual(values = c("#00AFBB", "#E7B800"))

## ----geom_boxplot-box-plot-one-variable, fig.width=3, fig.height=3.5-----
ggplot(wdata, aes(x = factor(1), y = weight)) +
  geom_boxplot(width = 0.4, fill = "white") +
  geom_jitter(aes(color = sex, shape = sex), 
              width = 0.1, size = 1) +
  scale_color_manual(values = c("#00AFBB", "#E7B800")) + 
  labs(x = NULL)   # Remove x axis label

## ----stat_ecdf-empirical-cumulative-distribution-function, fig.width = 5, fig.height=3.5----
# Another option for geom = "point"
a + stat_ecdf(aes(color = sex,linetype = sex), 
              geom = "step", size = 1.5) +
  scale_color_manual(values = c("#00AFBB", "#E7B800"))+
  labs(y = "f(weight)")

## ----quantile-quantile-qq-plot, fig.width = 5, fig.height=3.5------------
# Change point shapes by groups
ggplot(wdata, aes(sample = weight)) +
  stat_qq(aes(color = sex)) +
  scale_color_manual(values = c("#00AFBB", "#E7B800"))+
  labs(y = "Weight")

## ----ggqqplot-quantile-quantile-plot, fig.width=5, fig.height=3.5--------
library(ggpubr)
ggqqplot(wdata, x = "weight",
   color = "sex", 
   palette = c("#0073C2FF", "#FC4E07"),
   ggtheme = theme_pubclean())

## ---- eval = FALSE-------------------------------------------------------
## install.packages("ggridges")

## ------------------------------------------------------------------------
library(ggplot2)
library(ggridges)
theme_set(theme_ridges())

## ----ggridges, fig.width=5.5, fig.height=3.5-----------------------------
ggplot(iris, aes(x = Sepal.Length, y = Species)) +
  geom_density_ridges(aes(fill = Species)) +
  scale_fill_manual(values = c("#00AFBB", "#E7B800", "#FC4E07"))

## You can control the overlap between the different densities using the `scale` option. Default value is 1. Smaller values create a separation between the curves, and larger values create more overlap.

## ---- eval = FALSE-------------------------------------------------------
## ggplot(iris, aes(x = Sepal.Length, y = Species)) +
##   geom_density_ridges(scale = 0.9)

## ----ggridges-density-gradient, fig.width=7, fig.height=5----------------
ggplot(
  lincoln_weather, 
  aes(x = `Mean Temperature [F]`, y = `Month`)
  ) +
  geom_density_ridges_gradient(
    aes(fill = ..x..), scale = 3, size = 0.3
    ) +
  scale_fill_gradientn(
    colours = c("#0D0887FF", "#CC4678FF", "#F0F921FF"),
    name = "Temp. [F]"
    )+
  labs(title = 'Temperatures in Lincoln NE') 

## ---- eval = FALSE-------------------------------------------------------
## browseVignettes("ggridges")

## ------------------------------------------------------------------------
library(ggpubr)

## ------------------------------------------------------------------------
# Load data
dfm <- mtcars
# Convert the cyl variable to a factor
dfm$cyl <- as.factor(dfm$cyl)
# Add the name colums
dfm$name <- rownames(dfm)
# Inspect the data
head(dfm[, c("name", "wt", "mpg", "cyl")])

## ----ordered-bar-plots, fig.width=7, fig.height=4------------------------
ggbarplot(dfm, x = "name", y = "mpg",
          fill = "cyl",               # change fill color by cyl
          color = "white",            # Set bar border colors to white
          palette = "jco",            # jco journal color palett. see ?ggpar
          sort.val = "asc",          # Sort the value in dscending order
          sort.by.groups = TRUE,     # Don't sort inside each group
          x.text.angle = 90,           # Rotate vertically x axis texts
          ggtheme = theme_pubclean()
          )+
  font("x.text", size = 8, vjust = 0.5)

## To sort bars inside each group, use the argument **sort.by.groups = TRUE**

## ----lollipop-chart, fig.width=7, fig.height=4---------------------------
ggdotchart(dfm, x = "name", y = "mpg",
           color = "cyl",                                
           palette = c("#00AFBB", "#E7B800", "#FC4E07"), 
           sorting = "asc", sort.by.groups = TRUE,                      
           add = "segments",                            
           add.params = list(color = "lightgray", size = 2), 
           group = "cyl",                                
           dot.size = 4,                                 
           ggtheme = theme_pubclean()
           )+
  font("x.text", size = 8, vjust = 0.5)

## ---- eval = FALSE-------------------------------------------------------
## ggplot(diamonds, aes(cut)) +
##   geom_bar(fill = "#0073C2FF") +
##   theme_minimal()

## ---- eval = FALSE-------------------------------------------------------
## a <- ggplot(wdata, aes(x = weight))

## - **geom_density()**: density plot

## ----ggplot2-graphics-one-continuous-variable, echo = FALSE, fig.width=1.6, fig.height=1.7----
# One variable: continuous
a <- ggplot(wdata, aes(x = weight))
# area plot
a + geom_density() + ggtitle("a + geom_density()") + simple_theme
a + geom_histogram() + ggtitle("a + geom_histogram()") + simple_theme
a + geom_freqpoly() + ggtitle("a + geom_freqpoly()") + simple_theme
a + geom_area(stat = "bin") + ggtitle("a + geom_area()") + simple_theme
a + geom_dotplot(dotsize = 0.8) + ggtitle("a + geom_dotplot()") + simple_theme
a + stat_ecdf() + ggtitle("a + stat_ecdf()") + simple_theme
ggplot(mtcars, aes(sample=mpg)) + stat_qq() + ggtitle("x + stat_qq()") + simple_theme

